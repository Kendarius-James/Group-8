#from django.forms import ModelForm, models
#from accounts.models import CustomUser
from django import forms

'''
class RegistrationForm(forms.Form):
    email = forms.EmailField(max_length= 200)
'''
     
'''class Meta:
    model = CustomUser
    fields = ('email')
'''